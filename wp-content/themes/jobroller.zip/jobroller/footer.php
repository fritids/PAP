
            <div class="clear"></div>

        </div><!-- end inner -->

    </div><!-- end content -->
	
	<?php appthemes_before_footer(); ?>

    <div id="footer">

        	<div class="inner">

				<p><?php _e('Copyright &copy;','appthemes'); ?> <?php echo date_i18n('Y'); ?> <?php bloginfo('name'); ?>. <a href="http://www.appthemes.com/themes/jobroller/" target="_blank">Job Board Software</a> | <?php _e('Powered by','appthemes'); ?> <a href="http://wordpress.org" target="_blank">WordPress</a></p>

			</div><!-- end inner -->

    </div><!-- end footer -->
	
	<?php appthemes_after_footer(); ?>
	
</div><!-- end wrapper -->

<?php wp_footer(); ?>

<?php appthemes_after(); ?>

</body>

</html>